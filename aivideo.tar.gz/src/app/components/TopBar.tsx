import React from 'react';

export function TopBar() {
  return (
    <div className="h-20 bg-transparent border-b border-slate-200/60 flex items-center px-8 relative z-10">
      {/* TopBar - 已移除搜索框和设置按钮 */}
    </div>
  );
}
