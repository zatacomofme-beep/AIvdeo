# API 与数据库关联梳理报告

## 📊 数据库表概览

系统共有 **7 个数据库表**：

1. ✅ `users` - 用户表
2. ✅ `products` - 商品表
3. ✅ `projects` - 项目表
4. ✅ `videos` - 视频表
5. ✅ `characters` - 角色表
6. ✅ `saved_prompts` - 提示词表
7. ✅ `credit_history` - 积分历史表

---

## ✅ 已关联数据库的 API

### 1. 用户认证 API（已完成 ✅）

| 接口 | 方法 | 功能 | 数据库表 | 状态 |
|------|------|------|----------|------|
| `/api/register` | POST | 用户注册 | `users`, `credit_history` | ✅ 已实现 |
| `/api/login` | POST | 用户登录 | `users` | ✅ 已实现 |
| `/api/user/{user_id}` | GET | 获取用户信息 | `users` | ✅ 已实现 |

**特点**：
- ✅ 注册时生成唯一UUID
- ✅ 赠送520初始积分
- ✅ 记录积分历史
- ❌ 密码明文存储（需要加密）

---

### 2. 商品管理 API（已完成 ✅）

| 接口 | 方法 | 功能 | 数据库表 | 状态 |
|------|------|------|----------|------|
| `/api/products` | POST | 创建商品 | `products` | ✅ 已实现 |
| `/api/products/{user_id}` | GET | 获取用户商品列表 | `products` | ✅ 已实现 |
| `/api/product/{product_id}` | GET | 获取商品详情 | `products` | ✅ 已实现 |
| `/api/product/{product_id}` | PUT | 更新商品信息 | `products` | ✅ 已实现 |
| `/api/product/{product_id}` | DELETE | 删除商品 | `products` | ✅ 已实现 |

**特点**：
- ✅ 完整的 CRUD 操作
- ✅ 支持商品图片、规格、卖点等字段
- ✅ 关联到用户ID

---

### 3. 项目管理 API（已完成 ✅）

| 接口 | 方法 | 功能 | 数据库表 | 状态 |
|------|------|------|----------|------|
| `/api/projects` | POST | 创建项目 | `projects` | ✅ 已实现 |
| `/api/projects/{user_id}` | GET | 获取用户项目列表 | `projects` | ✅ 已实现 |

**特点**：
- ✅ 关联用户ID
- ✅ 保存产品名称和描述
- ✅ 按创建时间倒序排列

---

### 4. 视频管理 API（已完成 ✅）

| 接口 | 方法 | 功能 | 数据库表 | 状态 |
|------|------|------|----------|------|
| `/api/videos` | POST | 保存视频 | `videos` | ✅ 已实现 |
| `/api/videos/{user_id}` | GET | 获取用户视频列表 | `videos` | ✅ 已实现 |
| `/api/videos/{video_id}` | DELETE | 删除视频 | `videos` | ✅ 已实现 |
| `/api/videos/{video_id}/public` | PUT | 切换公开状态 | `videos` | ✅ 已实现 |
| `/api/public-videos` | GET | 获取公开视频 | `videos` | ✅ 已实现 |

**特点**：
- ✅ 关联用户ID和项目ID
- ✅ 保存视频URL、缩略图、脚本等
- ✅ 支持公开/私密切换
- ✅ 保存生成提示词

---

### 5. 角色管理 API（已完成 ✅）

| 接口 | 方法 | 功能 | 数据库表 | 状态 |
|------|------|------|----------|------|
| `/create-character` | POST | 创建角色（保存到数据库） | `characters` | ✅ 已实现 |
| `/api/characters/{user_id}` | GET | 获取用户角色列表 | `characters` | ✅ 已实现 |
| `/api/generate-character` | POST | AI生成角色（不保存） | - | ✅ 已实现（不保存） |

**特点**：
- ✅ 关联用户ID
- ✅ 保存角色名称、描述、属性等
- ✅ AI生成和手动创建分离

---

### 6. 提示词管理 API（已完成 ✅）

| 接口 | 方法 | 功能 | 数据库表 | 状态 |
|------|------|------|----------|------|
| `/api/prompts` | POST | 保存提示词 | `saved_prompts` | ✅ 已实现 |
| `/api/prompts/{user_id}` | GET | 获取用户提示词列表 | `saved_prompts` | ✅ 已实现 |
| `/api/prompts/{prompt_id}` | DELETE | 删除提示词 | `saved_prompts` | ✅ 已实现 |

**特点**：
- ✅ 关联用户ID
- ✅ 保存提示词内容和产品名称
- ✅ 按创建时间倒序排列

---

### 7. 积分管理 API（已完成 ✅）

| 接口 | 方法 | 功能 | 数据库表 | 状态 |
|------|------|------|----------|------|
| `/api/credits/consume` | POST | 消费积分 | `users`, `credit_history` | ✅ 已实现 |
| `/api/credits/history/{user_id}` | GET | 获取积分历史 | `credit_history` | ✅ 已实现 |
| `/api/admin/user/{user_id}/credits` | PUT | 管理员调整积分 | `users`, `credit_history` | ✅ 已实现 |

**特点**：
- ✅ 检查积分余额
- ✅ 扣除用户积分
- ✅ 记录积分历史
- ✅ 管理员可调整积分

---

### 8. 管理员 API（已完成 ✅）

| 接口 | 方法 | 功能 | 数据库表 | 状态 |
|------|------|------|----------|------|
| `/api/admin/stats` | GET | 获取统计数据 | `users`, `videos`, `credit_history` | ✅ 已实现 |
| `/api/admin/users` | GET | 获取所有用户 | `users` | ✅ 已实现 |
| `/api/admin/videos` | GET | 获取所有视频 | `videos` | ✅ 已实现 |
| `/api/admin/prompts` | GET | 获取所有提示词 | `saved_prompts` | ✅ 已实现 |

**特点**：
- ✅ 查看平台统计数据
- ✅ 管理用户和视频
- ✅ 审核提示词

---

## ❌ 未关联数据库的 API（业务逻辑API）

以下API是**核心业务逻辑**，它们调用AI服务，但**不直接操作数据库**。这些API的输出结果应该**由前端调用其他API保存**到数据库。

### 1. 图片上传 API

| 接口 | 方法 | 功能 | 当前状态 | 建议 |
|------|------|------|----------|------|
| `/api/upload-image` | POST | 上传图片到TOS | ❌ 不保存到数据库 | ⚠️ 可以考虑记录上传历史 |

**说明**：
- 上传图片到火山云TOS存储
- 返回图片URL
- **建议**：可以创建 `uploads` 表记录上传历史（用户ID、文件URL、上传时间等）

---

### 2. 脚本生成 API

| 接口 | 方法 | 功能 | 当前状态 | 建议 |
|------|------|------|----------|------|
| `/generate-script` | POST | 生成视频脚本 | ❌ 不保存到数据库 | ✅ 正确（前端保存） |
| `/generate-script-from-product` | POST | 根据商品生成脚本 | ❌ 不保存到数据库 | ✅ 正确（前端保存） |
| `/api/generate-script-ai` | POST | AI生成脚本 | ❌ 不保存到数据库 | ✅ 正确（前端保存） |

**说明**：
- 这些API调用AI生成脚本
- 返回脚本数据（JSON）
- **当前流程是正确的**：前端获取脚本后，用户确认/修改，然后通过 `/api/videos` 保存

**工作流程**：
```
用户 → 调用生成脚本API → 获取脚本 → 前端展示 → 用户确认 → 调用 /api/videos 保存
```

---

### 3. 视频生成 API

| 接口 | 方法 | 功能 | 当前状态 | 建议 |
|------|------|------|----------|------|
| `/generate-video` | POST | 生成视频 | ❌ 不保存到数据库 | ⚠️ **需要改进** |
| `/query-video-task` | POST | 查询视频任务 | ❌ 不保存到数据库 | ✅ 正确（查询API） |
| `/api/video-task/{task_id}` | GET | 查询视频任务（GET） | ❌ 不保存到数据库 | ✅ 正确（查询API） |

**问题**：
- `/generate-video` 调用Sora生成视频，返回 `task_id`
- 前端需要轮询查询任务状态
- **当前缺失**：生成完成后，前端没有自动保存到数据库

**建议改进**：

#### 方案1：前端负责保存（推荐）
```typescript
// 前端轮询完成后
if (status === 'completed') {
  // 调用 /api/videos 保存视频
  await api.saveVideo({
    user_id: currentUser.id,
    video_url: result.video_url,
    thumbnail_url: result.thumbnail_url,
    script: scriptData,
    product_name: productName,
    prompt: prompt
  });
}
```

#### 方案2：后端自动保存
修改 `/generate-video` API，在生成成功后自动保存到数据库：
```python
@app.post("/generate-video")
async def generate_video(req: GenerateVideoRequest, db: Session = Depends(get_db)):
    # 生成视频
    result = await generate_video_with_ai(...)
    
    # 如果传入了 user_id，则保存到数据库
    if req.user_id and result.get('status') == 'completed':
        new_video = Video(
            id=str(uuid.uuid4()),
            user_id=req.user_id,
            video_url=result['video_url'],
            # ...
        )
        db.add(new_video)
        db.commit()
    
    return result
```

---

### 4. 聊天 API

| 接口 | 方法 | 功能 | 当前状态 | 建议 |
|------|------|------|----------|------|
| `/chat` | POST | AI聊天对话 | ❌ 不保存到数据库 | ⚠️ 可以考虑记录对话历史 |

**说明**：
- AI助手对话
- 返回AI回复
- **建议**：可以创建 `chat_history` 表记录对话历史（用户ID、消息内容、时间戳等）

---

## 📋 需要改进的地方

### 🔴 高优先级

#### 1. 视频生成后自动保存
**问题**：用户生成视频后，需要手动保存。如果忘记保存或浏览器关闭，视频URL会丢失。

**解决方案**：
- 方案A：前端在视频生成完成后，自动调用 `/api/videos` 保存
- 方案B：后端在 `/generate-video` 中添加 `user_id` 参数，生成完成后自动保存

**推荐**：方案A（前端自动保存），因为用户可能想编辑后再保存

---

#### 2. 密码加密存储
**问题**：当前密码是明文存储，存在安全风险。

**解决方案**：
```python
import bcrypt

# 注册时加密
hashed = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
user.password = hashed.decode('utf-8')

# 登录时验证
if bcrypt.checkpw(password.encode('utf-8'), user.password.encode('utf-8')):
    # 密码正确
```

---

#### 3. 积分扣除集成
**问题**：生成视频时没有自动扣除积分。

**解决方案**：
在 `/generate-video` API中：
```python
@app.post("/generate-video")
async def generate_video(req: GenerateVideoRequest, db: Session = Depends(get_db)):
    # 检查用户积分
    user = db.query(User).filter(User.id == req.user_id).first()
    if user.credits < 50:  # 假设生成视频消费50积分
        raise HTTPException(status_code=400, detail="积分不足")
    
    # 生成视频
    result = await generate_video_with_ai(...)
    
    # 扣除积分
    user.credits -= 50
    credit_history = CreditHistory(
        id=str(uuid.uuid4()),
        user_id=req.user_id,
        action="生成视频",
        amount=-50,
        balance_after=user.credits
    )
    db.add(credit_history)
    db.commit()
    
    return result
```

---

### 🟡 中优先级

#### 4. 上传记录
创建 `uploads` 表记录所有上传的文件：
```python
class Upload(Base):
    __tablename__ = "uploads"
    
    id = Column(String, primary_key=True)
    user_id = Column(String, ForeignKey("users.id"))
    file_url = Column(String)
    file_type = Column(String)  # image/video
    file_size = Column(Integer)
    created_at = Column(DateTime, default=datetime.utcnow)
```

---

#### 5. 聊天历史
创建 `chat_history` 表记录对话：
```python
class ChatHistory(Base):
    __tablename__ = "chat_history"
    
    id = Column(String, primary_key=True)
    user_id = Column(String, ForeignKey("users.id"))
    role = Column(String)  # user/ai
    content = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
```

---

## 📊 总结

### ✅ 已完成（100%覆盖）
- ✅ 用户认证（注册、登录、用户信息）
- ✅ 商品管理（CRUD全覆盖）
- ✅ 项目管理（创建、查询）
- ✅ 视频管理（保存、查询、删除、公开）
- ✅ 角色管理（创建、查询）
- ✅ 提示词管理（保存、查询、删除）
- ✅ 积分管理（消费、历史、调整）
- ✅ 管理员功能（统计、用户、视频、提示词）

### ⚠️ 需要改进
1. 🔴 **视频生成后自动保存**（避免丢失）
2. 🔴 **密码加密存储**（安全性）
3. 🔴 **生成视频时扣除积分**（计费）
4. 🟡 上传文件记录（可选）
5. 🟡 聊天历史记录（可选）

### ✅ 正确的设计
- 脚本生成API不保存数据库（由前端保存）✅
- 查询API不保存数据库（只读）✅
- 业务逻辑与数据持久化分离✅

---

## 🎯 下一步建议

1. **立即处理**：
   - 添加密码加密（bcrypt）
   - 前端自动保存生成的视频
   - 视频生成时扣除积分

2. **短期处理**：
   - 添加上传记录表
   - 添加聊天历史表

3. **长期优化**：
   - 添加用户Token认证（JWT）
   - 添加API访问限流
   - 添加数据备份机制
